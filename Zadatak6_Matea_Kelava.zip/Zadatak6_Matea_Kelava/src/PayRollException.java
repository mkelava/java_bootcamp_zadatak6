class PayRollException extends Exception {
    public PayRollException(String message) {
        super(message);
    }
}
